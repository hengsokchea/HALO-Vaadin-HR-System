import {applyTheme as _applyTheme} from './theme-camhris.generated.js';
export const applyTheme = _applyTheme;
