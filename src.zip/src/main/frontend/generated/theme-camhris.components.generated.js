


if (!document['_vaadintheme_camhris_componentCss']) {
  
  document['_vaadintheme_camhris_componentCss'] = true;
}

if (import.meta.hot) {
  import.meta.hot.accept((module) => {
    window.location.reload();
  });
}

