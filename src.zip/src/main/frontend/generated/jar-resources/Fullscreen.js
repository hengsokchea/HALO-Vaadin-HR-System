/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/**
 * Returns the current fullscreen state synchronously. Used by the bootstrap
 * path to seed the server-side signal without waiting for a DOM event.
 */
export function currentFullscreenState() {
    if (document.fullscreenEnabled !== true) {
        return 'UNSUPPORTED';
    }
    return document.fullscreenElement ? 'FULLSCREEN' : 'NOT_FULLSCREEN';
}
// Dispatch on document.body so the server-side Page facade (listening on
// the UI element, which is body) can update its signal.
function dispatch(state) {
    document.body.dispatchEvent(new CustomEvent('vaadin-fullscreen-change', { detail: state }));
}
// Tracks the most recent component-fullscreen setup so the wrapper can be
// torn down when fullscreen exits (programmatically or via Escape) or when
// a new fullscreen request supersedes it.
let activeComponentReset;
function resetComponentIfActive() {
    if (activeComponentReset) {
        const fn = activeComponentReset;
        activeComponentReset = undefined;
        fn();
    }
}
document.addEventListener('fullscreenchange', () => {
    if (!document.fullscreenElement) {
        resetComponentIfActive();
    }
    dispatch(currentFullscreenState());
});
const $wnd = window;
$wnd.Vaadin ??= {};
$wnd.Vaadin.Flow ??= {};
$wnd.Vaadin.Flow.fullscreen = {
    /**
     * Requests fullscreen for the entire page (document.documentElement).
     * Resolves once the browser has entered fullscreen; rejects with the
     * browser's error if the request is refused (no user activation,
     * permissions policy, etc.) or with a custom error if fullscreen is not
     * supported.
     */
    async requestPageFullscreen() {
        resetComponentIfActive();
        if (document.fullscreenEnabled !== true) {
            throw new Error('Fullscreen is not supported');
        }
        await document.documentElement.requestFullscreen();
    },
    /**
     * Requests fullscreen for a specific component by moving it into the
     * given wrapper element and hiding the rest of the view. Fullscreens
     * document.documentElement so that Vaadin theming and overlay
     * components keep working. The component is restored to its original
     * position on exit (programmatic, Escape, or a superseding request).
     * If the browser rejects the request, the DOM is rolled back before the
     * promise rejects with the browser's error.
     */
    async requestComponentFullscreen(element, wrapper) {
        resetComponentIfActive();
        if (document.fullscreenEnabled !== true) {
            throw new Error('Fullscreen is not supported');
        }
        const originalParent = element.parentNode;
        if (!originalParent) {
            throw new Error('Component is not attached to the DOM');
        }
        // The view root is the wrapper's current element child (the route
        // content). Capture it before touching the DOM, because the steps below
        // insert a placeholder comment and move the element into the wrapper —
        // after that, the wrapper's first node may be the placeholder rather than
        // the view root. Use firstElementChild so comment/text nodes are skipped.
        const viewRoot = wrapper.firstElementChild;
        const placeholder = document.createComment('vaadin-fullscreen-placeholder');
        originalParent.insertBefore(placeholder, element);
        wrapper.appendChild(element);
        // When the fullscreened component *is* the view root there is nothing
        // else to hide; hiding it would blank the fullscreen. Otherwise hide the
        // view root so only the fullscreened component shows.
        const hidden = viewRoot === element ? null : viewRoot;
        const previousDisplay = hidden?.style.display ?? '';
        if (hidden) {
            hidden.style.display = 'none';
        }
        activeComponentReset = () => {
            placeholder.parentNode?.insertBefore(element, placeholder);
            placeholder.remove();
            if (hidden) {
                hidden.style.display = previousDisplay;
            }
        };
        try {
            await document.documentElement.requestFullscreen();
        }
        catch (e) {
            // Browser rejected the request — undo the DOM changes so the page
            // does not end up looking fullscreened without actually being so.
            resetComponentIfActive();
            throw e;
        }
    },
    /**
     * Exits fullscreen mode if the page is currently in fullscreen.
     */
    exitFullscreen() {
        if (document.fullscreenElement) {
            document.exitFullscreen();
        }
    }
};
//# sourceMappingURL=Fullscreen.js.map