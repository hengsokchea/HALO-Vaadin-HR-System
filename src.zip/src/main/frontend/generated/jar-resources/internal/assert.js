/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
// Mirrors Java's `assert condition : message`. The flow-client TypeScript port
// keeps these as always-on runtime guards. GWT strips assertions from
// production, so this is intentionally stricter than the original Java
// production behaviour: invariant violations surface immediately rather than
// corrupting state or emitting malformed output silently.
/**
 * Throws an Error with the given message when the condition is falsy.
 *
 * Java evaluates the message expression only when the assertion fails, so a
 * caller on a hot path passes a function and pays for the message only then.
 */
export function assert(condition, message) {
    if (!condition) {
        throw new Error(typeof message === 'function' ? message() : message);
    }
}
//# sourceMappingURL=assert.js.map