/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
// TypeScript port of com.vaadin.client.ApplicationConnection.
// The static create() assembles the DefaultRegistry, binds the root state node to
// the page body, and publishes the client API. The instance API
// (start/isActive/poll/resolveUri/sendEventMessage/...) drives the application.
// create() is the entry point the ported Bootstrapper calls; the live page still
// starts the GWT engine, so nothing calls it outside the tests until cutover.
//
// Two deviations from the Java class:
//
// - Java does all of this in its public constructor, which can publish the client
//   API because the instance exists inside it. Here the publication is a separate
//   module (publishClient), so the connection has to exist before it can be
//   published: the constructor takes the assembled registry and create() is the
//   entry point that mirrors the Java constructor. That is also why the members
//   the JSNI blocks reach - isActive, getDomElementByNodeId, getNodeId,
//   addDomSetListener, getJavaClass, isHiddenByServer, getElementStyleProperties -
//   are public here although Java keeps them private: JSNI reads private members
//   of the enclosing class, a separate module cannot.
// - The Styles JavaScriptObject that getElementStyleProperties fills is not
//   ported: it exists to give JSNI a typed handle on a plain JS object, which a
//   TypeScript object literal already is.
import { bind } from './flow/binding/Binder';
import { observe as observeLoadingIndicator } from './communication/LoadingIndicatorConfigurator';
import { observe as observePoll } from './communication/PollConfigurator';
import { ReconnectConfiguration } from './communication/ReconnectConfiguration';
import { DefaultRegistry } from './DefaultRegistry';
import { NodeFeatures } from '../flow/internal/nodefeature/NodeFeatures';
import { NodeProperties } from '../flow/internal/nodefeature/NodeProperties';
import { publishClient } from './publishClient';
import { getScheduler } from './TrackingScheduler';
/** The main class for an application/UI; mirrors ApplicationConnection.java's engine API. */
// GWT's uncaught exception handler is a single, replaceable slot: creating
// another connection replaced the handler instead of adding one. Mirror that
// with one window listener, installed on the first connection and dispatching to
// the handler of the most recently created one, so several applications on a
// page do not report the same error once per connection.
//
// The listener is wider than the Java original in one way that has no
// TypeScript equivalent: GWT only routed exceptions thrown inside $entry-wrapped
// engine code, while a window error listener also sees errors thrown by
// unrelated page scripts.
let uncaughtErrorHandler = null;
function setUncaughtErrorHandler(handler) {
    if (uncaughtErrorHandler === null) {
        window.addEventListener('error', (event) => uncaughtErrorHandler?.(event.error ?? event.message));
    }
    uncaughtErrorHandler = handler;
}
/**
 * Checks if deferred commands are (potentially) still being executed as a result
 * of an update from the server. Returns true if a deferred command might still be
 * executing, false otherwise. This will not work correctly if a deferred command
 * is added in another deferred command.
 *
 * Used by the native "client.isActive" function.
 *
 * Java asks Scheduler.get() and checks whether it is a TrackingScheduler; the
 * port has only that scheduler, so it reads the shared instance directly.
 *
 * @returns true if deferred commands are (potentially) being executed, false
 *          otherwise
 */
function isExecutingDeferredCommands() {
    return getScheduler().hasWorkQueued();
}
/**
 * Main class for an application / UI.
 *
 * Initializes the registry and starts the application.
 */
export class ApplicationConnection {
    #registry;
    constructor(registry) {
        this.#registry = registry;
    }
    /**
     * Creates an application connection using the given configuration: assembles
     * the {@link DefaultRegistry}, binds the root state node to the page body, and
     * publishes the client API through {@link publishClient}. Mirrors the
     * ApplicationConnection.java constructor.
     *
     * @param applicationConfiguration - the configuration object for the application
     * @returns the connection, already published
     */
    static create(applicationConfiguration) {
        const rootElement = document.body;
        const registry = new DefaultRegistry(applicationConfiguration);
        // Route uncaught errors to the system error handler (GWT's uncaught handler).
        const systemErrorHandler = registry.getSystemErrorHandler();
        setUncaughtErrorHandler((error) => systemErrorHandler.handleErrorObject(error));
        const rootNode = registry.getStateTree().getRootNode();
        // Bind the UI configuration objects.
        observePoll(rootNode, registry.getPoller());
        ReconnectConfiguration.bind(registry.getConnectionStateHandler());
        observeLoadingIndicator(rootNode);
        rootNode.setDomNode(rootElement);
        bind(rootNode, rootElement);
        const connection = new ApplicationConnection(registry);
        registry.setApplicationConnection(connection);
        publishClient(connection, applicationConfiguration);
        return connection;
    }
    /**
     * Starts this application. Public access is required for web components.
     *
     * @param initialUidl - the initial UIDL or null if the server did not provide
     *          any
     */
    start(initialUidl) {
        if (initialUidl === null) {
            // Initial UIDL not in the DOM; request it from the server.
            this.#registry.getMessageSender().resynchronize();
        }
        else {
            // Initial UIDL provided in the DOM, continue as if returned by request.
            //
            // Hack to avoid logging an error in endRequest().
            this.#registry.getRequestResponseTracker().startRequest();
            this.#registry.getMessageHandler().handleMessage(initialUidl);
        }
        window.addEventListener('pagehide', () => this.#registry.getMessageSender().sendUnloadBeacon());
        window.addEventListener('pageshow', () => {
            // Currently only Safari gets here, sometimes when going back/forward with
            // browser buttons. Chrome discards our state as beforeunload is used. As
            // state is most likely cleared on the server already (especially now with
            // the Beacon API request), it is probably better to resynchronize the
            // state (which would happen on the first server visit).
            window.location.reload();
        });
    }
    /**
     * Checks if there is some work to be done on the client side.
     *
     * @returns true if the client has some work to be done, false otherwise
     */
    isActive() {
        return (!this.#registry.getMessageHandler().isInitialUidlHandled() ||
            this.#registry.getRequestResponseTracker().hasActiveRequest() ||
            isExecutingDeferredCommands());
    }
    // The members the JSNI blocks publish, in the order publishJavascriptMethods
    // publishes them, followed by the development-mode block's. Java declares
    // getDomElementByNodeId, getNodeId and addDomSetListener among its helpers
    // below and reaches the rest inline from the JSNI; grouping them by the
    // publication keeps each block readable against its Java original.
    /** The DOM node bound to the state node with the given id, or null. */
    getDomElementByNodeId(id) {
        const node = this.#registry.getStateTree().getNode(id);
        return node === null ? null : node.getDomNode();
    }
    /** The state node id bound to the given DOM element, or -1 if none. */
    getNodeId(element) {
        const node = this.#registry.getStateTree().getStateNodeForDomNode(element);
        return node === null ? -1 : node.getId();
    }
    /** The id of the UI this connection is connected to. */
    getUIId() {
        return this.#registry.getApplicationConfiguration().getUIId();
    }
    /** Runs the callback once the DOM node for the given state node id is set. */
    addDomSetListener(nodeId, callback) {
        // Mirror Java's non-null deref: getNode(nodeId).addDomNodeSetListener throws
        // if the node is unknown, so use `!` (a TypeError on null) rather than `?.`
        // (which would silently do nothing).
        const node = this.#registry.getStateTree().getNode(nodeId);
        node.addDomNodeSetListener((boundNode) => {
            if (boundNode.getId() === nodeId) {
                callback();
                return true;
            }
            return false;
        });
    }
    /** Triggers a server poll. */
    poll() {
        this.#registry.getPoller().poll();
    }
    /** Connects the web component described by the event data with the server. */
    connectWebComponent(eventData) {
        const nodeId = this.#registry.getStateTree().getRootNode().getId();
        this.#registry.getServerConnector().sendEventMessage(nodeId, 'connect-web-component', eventData);
    }
    /** Profiling data for the last request (processing times + server timing + bootstrap). */
    getProfilingData() {
        return this.#registry.getMessageHandler().getProfilingData();
    }
    /** Resolves a Vaadin URI (context://, base://) to an absolute URL. */
    resolveUri(uri) {
        return this.#registry.getURIResolver().resolveVaadinUri(uri);
    }
    /** Sends an event message to the server. */
    sendEventMessage(nodeId, eventType, eventData) {
        this.#registry.getServerConnector().sendEventMessage(nodeId, eventType, eventData);
    }
    /** A JSON description of the root node's state tree, for debugging. */
    debug() {
        return this.#registry.getStateTree().getRootNode().getDebugJson();
    }
    // The helpers only the dev-tools methods call, in the order Java declares them.
    /** The Java class name bound to the state node with the given id, or null. */
    getJavaClass(id) {
        const node = this.#registry.getStateTree().getNode(id);
        if (node === null) {
            return null;
        }
        return node.getMap(NodeFeatures.ELEMENT_DATA).getProperty(NodeProperties.JAVA_CLASS).getValueOrDefault(null);
    }
    /** Whether the element for the given state node id is hidden by the server. */
    isHiddenByServer(id) {
        const node = this.#registry.getStateTree().getNode(id);
        const visible = node === null
            ? true
            : node.getMap(NodeFeatures.ELEMENT_DATA).getProperty(NodeProperties.VISIBLE).getValueOrDefault(true);
        return !visible;
    }
    /** The element style properties for the given state node id, as a plain object. */
    getElementStyleProperties(id) {
        const styles = {};
        const node = this.#registry.getStateTree().getNode(id);
        if (node !== null) {
            const styleMap = node.getMap(NodeFeatures.ELEMENT_STYLE_PROPERTIES);
            for (const name of styleMap.getPropertyNames()) {
                styles[name] = styleMap.getProperty(name).getValue();
            }
        }
        return styles;
    }
}
//# sourceMappingURL=ApplicationConnection.js.map