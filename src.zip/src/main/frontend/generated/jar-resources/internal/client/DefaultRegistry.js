/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
import { atmospherePushConnectionFactory } from './communication/AtmospherePushConnection';
import { ConstantPool } from './flow/ConstantPool';
import { DependencyLoader } from './DependencyLoader';
import { DefaultConnectionStateHandler } from './communication/DefaultConnectionStateHandler';
import { Heartbeat } from './communication/Heartbeat';
import { LoadingIndicatorStateHandler } from './communication/LoadingIndicatorStateHandler';
import { MessageHandler } from './communication/MessageHandler';
import { MessageSender } from './communication/MessageSender';
import { Poller } from './communication/Poller';
import { PushConfiguration } from './communication/PushConfiguration';
import { ReconnectConfiguration } from './communication/ReconnectConfiguration';
import { Registry, TOKEN } from './Registry';
import { RequestResponseTracker } from './communication/RequestResponseTracker';
import { ResourceLoader } from './ResourceLoader';
import { ServerConnector } from './communication/ServerConnector';
import { ServerRpcQueue } from './communication/ServerRpcQueue';
import { ExecuteJavaScriptProcessor } from './flow/ExecuteJavaScriptProcessor';
import { ExistingElementMap } from './ExistingElementMap';
import { InitialPropertiesHandler } from './InitialPropertiesHandler';
import { StateTree } from './flow/StateTree';
import { SystemErrorHandler } from './SystemErrorHandler';
import { UILifecycle } from './UILifecycle';
import { URIResolver } from './URIResolver';
import { XhrConnection } from './communication/XhrConnection';
/**
 * A registry implementation used by {@link ApplicationConnection}.
 */
export class DefaultRegistry extends Registry {
    /**
     * Constructs a registry based on the given configuration reference.
     *
     * Java also takes the application connection here, because the registry is
     * constructed from inside ApplicationConnection's constructor; the port
     * registers it through {@link DefaultRegistry.setApplicationConnection} instead.
     *
     * @param applicationConfiguration - the application configuration
     */
    constructor(applicationConfiguration) {
        super();
        // Initialization order matters: many constructors read earlier services.
        this.set(TOKEN.ApplicationConfiguration, applicationConfiguration);
        // No constructor dependencies (resolve collaborators lazily via getters).
        this.set(TOKEN.ResourceLoader, new ResourceLoader(this, true));
        this.set(TOKEN.URIResolver, new URIResolver(this));
        this.set(TOKEN.DependencyLoader, new DependencyLoader(this));
        this.set(TOKEN.SystemErrorHandler, new SystemErrorHandler(this));
        this.setResettable(TOKEN.UILifecycle, () => new UILifecycle());
        this.set(TOKEN.StateTree, new StateTree(this));
        this.set(TOKEN.RequestResponseTracker, new RequestResponseTracker(this));
        this.set(TOKEN.MessageHandler, new MessageHandler(this));
        this.set(TOKEN.MessageSender, new MessageSender(this, atmospherePushConnectionFactory));
        this.set(TOKEN.ServerRpcQueue, new ServerRpcQueue(this));
        this.set(TOKEN.ServerConnector, new ServerConnector(this));
        this.set(TOKEN.ExecuteJavaScriptProcessor, new ExecuteJavaScriptProcessor(this));
        this.setResettable(TOKEN.ConstantPool, () => new ConstantPool());
        this.setResettable(TOKEN.ExistingElementMap, () => new ExistingElementMap());
        this.set(TOKEN.InitialPropertiesHandler, new InitialPropertiesHandler(this));
        // Classes with dependencies, in order.
        this.setResettable(TOKEN.Heartbeat, () => new Heartbeat(this));
        this.set(TOKEN.ConnectionStateHandler, new DefaultConnectionStateHandler(this));
        this.set(TOKEN.XhrConnection, new XhrConnection(this));
        this.set(TOKEN.PushConfiguration, new PushConfiguration(this));
        this.set(TOKEN.ReconnectConfiguration, new ReconnectConfiguration(this));
        this.set(TOKEN.Poller, new Poller(this));
        this.set(TOKEN.LoadingIndicatorStateHandler, new LoadingIndicatorStateHandler(this));
    }
    /**
     * Stores the application connection this registry belongs to.
     *
     * Java takes the connection as the first constructor parameter, because the
     * registry is constructed from inside ApplicationConnection's constructor. The
     * port assembles the registry first and hands the connection over as soon as it
     * exists, which is before anything can look it up.
     *
     * @param connection - the application connection
     */
    setApplicationConnection(connection) {
        this.set(TOKEN.ApplicationConnection, connection);
    }
}
//# sourceMappingURL=DefaultRegistry.js.map