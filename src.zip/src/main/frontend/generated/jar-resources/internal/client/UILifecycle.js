/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/** The lifecycle state of a UI; the order defines the allowed forward transitions. */
export const UIState = {
    INITIALIZING: 'INITIALIZING',
    RUNNING: 'RUNNING',
    TERMINATED: 'TERMINATED'
};
// Ordinals matching the Java enum order, used to enforce single-step forward
// transitions.
const ORDINAL = {
    INITIALIZING: 0,
    RUNNING: 1,
    TERMINATED: 2
};
/**
 * Manages the lifecycle of a UI.
 */
export class UILifecycle {
    #state = UIState.INITIALIZING;
    // A list, not a set: GWT's SimpleEventBus registers the same handler twice if
    // added twice, and one removal detaches one registration.
    #handlers = [];
    /**
     * Gets the state of the UI.
     *
     * @returns the current state of the UI
     */
    getState() {
        return this.#state;
    }
    /**
     * Sets the state of the UI to the given value.
     *
     * Only allows state changes in one direction: {@link UIState.INITIALIZING}
     * -\> {@link UIState.RUNNING} -\> {@link UIState.TERMINATED}.
     *
     * Changing the state fires a {@link StateChangeEvent}.
     *
     * @param state - the new UI state
     */
    setState(state) {
        if (ORDINAL[state] !== ORDINAL[this.#state] + 1) {
            throw new Error(`Tried to move from state ${this.#state} to ${state} which is not allowed`);
        }
        this.#state = state;
        const event = { getUiLifecycle: () => this };
        // Iterate a copy, as SimpleEventBus does, so a handler added or removed
        // during dispatch does not change who is notified for this event.
        [...this.#handlers].forEach((handler) => handler(event));
    }
    /**
     * Check if the state is {@link UIState.RUNNING}.
     *
     * @returns `true` if the status is {@link UIState.RUNNING}, `false`
     *          otherwise
     */
    isRunning() {
        return this.#state === UIState.RUNNING;
    }
    /**
     * Check if the state is {@link UIState.TERMINATED}.
     *
     * @returns `true` if the status is {@link UIState.TERMINATED}, `false`
     *          otherwise
     */
    isTerminated() {
        return this.#state === UIState.TERMINATED;
    }
    /**
     * Adds a state change event handler.
     *
     * @param handler - the handler to add
     * @returns a handler registration object which can be used to remove the
     *          handler
     */
    addHandler(handler) {
        this.#handlers.push(handler);
        return {
            remove: () => {
                const index = this.#handlers.indexOf(handler);
                if (index >= 0) {
                    this.#handlers.splice(index, 1);
                }
            }
        };
    }
}
//# sourceMappingURL=UILifecycle.js.map