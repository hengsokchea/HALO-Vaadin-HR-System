/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
import { endEagerDependencyLoading, runWhenEagerDependenciesLoaded, startEagerDependencyLoading } from './EagerDependencyTracker';
import { Console } from './Console';
import { getScheduler } from './TrackingScheduler';
// com.vaadin.flow.shared.ui.Dependency
const KEY_URL = 'url';
const KEY_TYPE = 'type';
const KEY_CONTENTS = 'contents';
const KEY_ID = 'id';
/**
 * Handles loading of dependencies (stylesheets and scripts) in the application.
 */
export class DependencyLoader {
    #registry;
    // Loads the next eager dependency when the current one completes.
    #eagerListener = {
        onLoad: () => endEagerDependencyLoading(),
        onError: (event) => {
            Console.error(`'${event.getResourceData()}' could not be loaded.`);
            // The show must go on.
            endEagerDependencyLoading();
        }
    };
    #lazyListener = {
        onLoad: () => {
            // Nothing to do on success; simply continue loading.
        },
        onError: (event) => {
            Console.error(`${event.getResourceData()} could not be loaded.`);
        }
    };
    /**
     * Creates a new instance connected to the given registry.
     *
     * @param registry - the global registry
     */
    constructor(registry) {
        this.#registry = registry;
    }
    #loadLazyDependency(dependencyUrl, loader) {
        loader(dependencyUrl, this.#lazyListener);
    }
    #loadDependencyEagerly(data, loader) {
        startEagerDependencyLoading();
        loader(data, this.#eagerListener);
    }
    /**
     * Triggers loading of the given dependencies.
     *
     * @param clientDependencies - the map of the dependencies to load, divided into groups by load mode, not `null`.
     */
    loadDependencies(clientDependencies) {
        // Java asserts clientDependencies != null; the parameter is non-nullable,
        // so the check is unreachable and dropped.
        const lazyDependencies = new Map();
        clientDependencies.forEach((dependencies, mode) => {
            this.#extractLazyDependenciesAndLoadOthers(mode, dependencies).forEach((loader, url) => {
                lazyDependencies.set(url, loader);
            });
        });
        // Postpone lazy dependencies until after the eager ones (and the browser
        // event loop) so they don't block commands queued after the eager load.
        if (lazyDependencies.size > 0) {
            runWhenEagerDependenciesLoaded(() => {
                getScheduler().scheduleDeferred(() => {
                    Console.debug('Finished loading eager dependencies, loading lazy.');
                    lazyDependencies.forEach((loader, url) => this.#loadLazyDependency(url, loader));
                });
            });
        }
    }
    #extractLazyDependenciesAndLoadOthers(loadMode, dependencies) {
        const lazyDependencies = new Map();
        for (const dependency of dependencies) {
            const type = dependency[KEY_TYPE];
            const dependencyId = KEY_ID in dependency ? dependency[KEY_ID] : null;
            const resourceLoader = this.#getResourceLoader(type, loadMode, dependencyId);
            if (type === 'DYNAMIC_IMPORT') {
                this.#loadDependencyEagerly(dependency[KEY_URL], resourceLoader);
            }
            else {
                switch (loadMode) {
                    case 'EAGER':
                        this.#loadDependencyEagerly(this.#getDependencyUrl(dependency), resourceLoader);
                        break;
                    case 'LAZY':
                        lazyDependencies.set(this.#getDependencyUrl(dependency), resourceLoader);
                        break;
                    case 'INLINE':
                        this.#loadDependencyEagerly(dependency[KEY_CONTENTS], resourceLoader);
                        break;
                    default:
                        throw new Error(`Unknown load mode = ${loadMode}`);
                }
            }
        }
        return lazyDependencies;
    }
    #getDependencyUrl(dependency) {
        // Java passes the resolver result straight on; resolveVaadinUri only returns
        // null for a null uri, and a dependency always carries its url.
        return this.#registry.getURIResolver().resolveVaadinUri(dependency[KEY_URL]);
    }
    #getResourceLoader(resourceType, loadMode, dependencyId) {
        const resourceLoader = this.#registry.getResourceLoader();
        const inline = loadMode === 'INLINE';
        switch (resourceType) {
            case 'STYLESHEET':
                if (inline) {
                    return (data, listener) => resourceLoader.inlineStyleSheet(data, listener, dependencyId);
                }
                return (url, listener) => resourceLoader.loadStylesheet(url, listener, dependencyId);
            case 'JAVASCRIPT':
                if (inline) {
                    return (data, listener) => resourceLoader.inlineScript(data, listener);
                }
                return (scriptUrl, listener) => resourceLoader.loadScript(scriptUrl, listener, false, true);
            case 'JS_MODULE':
                if (inline) {
                    throw new Error('Inline load mode is not supported for JsModule.');
                }
                return (scriptUrl, listener) => resourceLoader.loadJsModule(scriptUrl, listener, false, true);
            case 'DYNAMIC_IMPORT':
                return (expression, listener) => resourceLoader.loadDynamicImport(expression, listener);
            default:
                throw new Error(`Unknown dependency type ${resourceType}`);
        }
    }
}
//# sourceMappingURL=DependencyLoader.js.map