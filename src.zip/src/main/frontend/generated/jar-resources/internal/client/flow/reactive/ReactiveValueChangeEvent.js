/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/**
 * Event fired when a reactive value has changed.
 */
export class ReactiveValueChangeEvent {
    #source;
    /**
     * Creates a new event fired from a source.
     *
     * @param source - the reactive value that will fire the event
     */
    constructor(source) {
        this.#source = source;
    }
    /**
     * Gets the reactive value from which this event originates.
     *
     * @returns the event source
     */
    getSource() {
        return this.#source;
    }
}
//# sourceMappingURL=ReactiveValueChangeEvent.js.map