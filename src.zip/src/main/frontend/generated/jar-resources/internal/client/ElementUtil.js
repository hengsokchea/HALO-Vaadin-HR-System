/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/**
 * Utils class, intended to ease working with DOM elements on client side.
 *
 * Migrated from `com.vaadin.client.ElementUtil`, which stays in place until the
 * GWT client is retired.
 */
/**
 * Checks whether the `node` has required `tag`.
 *
 * @param node - the node to check
 * @param tag - the required tag name
 * @returns `true` if the node has required tag name
 */
export function hasTag(node, tag) {
    return node instanceof Element && node.tagName.toLowerCase() === tag.toLowerCase();
}
/**
 * Searches the shadow root of the given context element for the given id or
 * searches the light DOM if the element has no shadow root.
 *
 * @param context - the container element to search through
 * @param id - the identifier of the element to search for
 * @returns the element with the given `id` if found, otherwise
 *          `null`
 */
export function getElementById(context, id) {
    const bodyExports = document.body.$;
    if (bodyExports && bodyExports.hasOwnProperty && bodyExports.hasOwnProperty(id)) {
        // Exported web components add their id to body.$ and cannot be found using
        // a real id attribute.
        return bodyExports[id];
    }
    const ctx = context;
    if (ctx.shadowRoot) {
        return ctx.shadowRoot.getElementById(id);
    }
    else if (ctx.getElementById) {
        return ctx.getElementById(id);
    }
    else if (id && id.match('^[a-zA-Z0-9-_]*$')) {
        // No funky characters in id so querySelector can be used directly.
        return ctx.querySelector('#' + id);
    }
    // Find all elements with an id attribute and filter out the correct one.
    return Array.from(ctx.querySelectorAll('[id]')).find((e) => e.id === id) ?? null;
}
/** Searches the context for an element with the given `name` attribute. */
export function getElementByName(context, name) {
    return (Array.from(context.querySelectorAll('[name]')).find((e) => e.getAttribute('name') === name) ?? null);
}
//# sourceMappingURL=ElementUtil.js.map