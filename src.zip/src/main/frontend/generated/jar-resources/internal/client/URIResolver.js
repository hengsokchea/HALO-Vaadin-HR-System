/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
import { VaadinUriResolver } from '../flow/shared/VaadinUriResolver';
/** Client side URL resolver for vaadin protocols. */
export class URIResolver extends VaadinUriResolver {
    #registry;
    /**
     * Creates a new instance connected to the given registry.
     *
     * @param registry - the global registry
     */
    constructor(registry) {
        super();
        this.#registry = registry;
    }
    /**
     * Translates a Vaadin URI to a URL that can be loaded by the browser. The
     * following URI schemes are supported:
     *
     * - `context://` - resolves to the application context root
     * - `base://` - resolves to the base URI of the page
     *
     * Any other URI protocols, such as `http://` or `https://` are passed through
     * this method unmodified.
     *
     * @param uri - the URI to resolve
     * @returns the resolved URI
     */
    resolveVaadinUri(uri) {
        return super.resolveVaadinUri(uri, this.getContextRootUrl());
    }
    getContextRootUrl() {
        return this.#registry.getApplicationConfiguration().getContextRootUrl();
    }
}
/**
 * Returns the current document location as relative to the base uri of the document.
 *
 * @returns the document current location as relative to the document base uri
 */
export function getCurrentLocationRelativeToBaseUri() {
    return getBaseRelativeUri(document.baseURI, window.location.href);
}
/**
 * Returns the given uri as relative to the given base uri.
 *
 * @param baseURI - the base uri of the document
 * @param uri - an absolute uri to transform
 * @returns the uri as relative to the document base uri, or the given uri * unmodified
 *          if it is for different context.
 */
export function getBaseRelativeUri(baseURI, uri) {
    if (uri.startsWith(baseURI)) {
        return uri.substring(baseURI.length);
    }
    return uri;
}
//# sourceMappingURL=URIResolver.js.map