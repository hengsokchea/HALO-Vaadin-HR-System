/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/**
 * Misc internal utility methods used by both the server and the client package.
 *
 * TypeScript port of the full public API of
 * com.vaadin.flow.shared.util.SharedUtil, built alongside the Java version.
 * Java-private helpers are kept as non-exported module-local functions.
 */
/**
 * Trims trailing slashes (if any) from a string.
 *
 * @param value - The string value to be trimmed. Cannot be null.
 * @returns String value without trailing slashes.
 */
export function trimTrailingSlashes(value) {
    return value.replace(/\/*$/, '');
}
/**
 * Tells whether the given single character is an upper case letter, mirroring
 * Java's Character.isUpperCase for the characters exercised by these helpers.
 * Digits, spaces and other non-cased characters are not upper case because
 * their upper and lower case forms are identical.
 */
function isUpperCase(c) {
    return c !== c.toLowerCase() && c === c.toUpperCase();
}
/**
 * Splits a string on a literal separator, mirroring Java's
 * String.split(regex) with the default (zero) limit: trailing empty strings
 * are removed. The empty input string still yields a single empty element, as
 * it does in Java.
 */
function splitRemovingTrailingEmpty(value, separator) {
    const parts = value.split(separator);
    if (value === '') {
        // Java's split returns a single empty string for empty input.
        return parts;
    }
    let end = parts.length;
    while (end > 0 && parts[end - 1] === '') {
        end--;
    }
    return parts.slice(0, end);
}
/**
 * Splits a camelCaseString into an array of words with the casing preserved.
 *
 * @param camelCaseString - The input string in camelCase format
 * @returns An array with one entry per word in the input string
 */
export function splitCamelCase(camelCaseString) {
    let sb = '';
    for (let i = 0; i < camelCaseString.length; i++) {
        const c = camelCaseString.charAt(i);
        if (isUpperCase(c) && isWordComplete(camelCaseString, i)) {
            sb += ' ';
        }
        sb += c;
    }
    return splitRemovingTrailingEmpty(sb, ' ');
}
/**
 * Tells whether a word ends at the given upper case character while splitting
 * a camelCase string.
 */
function isWordComplete(camelCaseString, i) {
    if (i === 0) {
        // Word can't end at the beginning
        return false;
    }
    else if (!isUpperCase(camelCaseString.charAt(i - 1))) {
        // Word ends if previous char wasn't upper case
        return true;
    }
    else if (i + 1 < camelCaseString.length && !isUpperCase(camelCaseString.charAt(i + 1))) {
        // Word ends if next char isn't upper case
        return true;
    }
    else {
        return false;
    }
}
/**
 * Converts a camelCaseString to a human friendly format (Camel case string).
 * In general splits words when the casing changes but also handles special
 * cases such as consecutive upper case characters. Examples:
 * `MyBeanContainer` becomes `My Bean Container`, `AwesomeURLFactory` becomes
 * `Awesome URL Factory`, `SomeUriAction` becomes `Some Uri Action`.
 *
 * @param camelCaseString - The input string in camelCase format
 * @returns A human friendly version of the input
 */
export function camelCaseToHumanFriendly(camelCaseString) {
    const parts = splitCamelCase(camelCaseString);
    for (let i = 0; i < parts.length; i++) {
        parts[i] = capitalize(parts[i]);
    }
    return join(parts, ' ');
}
/**
 * Joins the words in the input array together into a single string by
 * inserting the separator string between each word.
 *
 * @param parts - The array of words
 * @param separator - The separator string to use between words
 * @returns The constructed string of words and separators
 */
export function join(parts, separator) {
    let sb = '';
    for (const part of parts) {
        sb += part;
        sb += separator;
    }
    return sb.substring(0, sb.length - separator.length);
}
/**
 * Capitalizes the first character in the given string in a way suitable for
 * use in code (methods, properties etc).
 *
 * @param string - The string to capitalize
 * @returns The capitalized string
 */
export function capitalize(string) {
    if (string === null) {
        return null;
    }
    if (string.length <= 1) {
        return string.toUpperCase();
    }
    return string.substring(0, 1).toUpperCase() + string.substring(1);
}
/**
 * Changes the first character in the given string to lower case in a way
 * suitable for use in code (methods, properties etc).
 *
 * @param string - The string to change
 * @returns The string with initial character turned into lower case
 */
export function firstToLower(string) {
    if (string === null) {
        return null;
    }
    if (string.length <= 1) {
        return string.toLowerCase();
    }
    return string.substring(0, 1).toLowerCase() + string.substring(1);
}
/**
 * Converts a property id to a human friendly format. Handles nested
 * properties by only considering the last part, e.g. "address.streetName" is
 * equal to "streetName" for this method.
 *
 * @param propertyId - The propertyId to format
 * @returns A human friendly version of the property id
 */
export function propertyIdToHumanFriendly(propertyId) {
    let string = String(propertyId);
    if (string.length === 0) {
        return '';
    }
    // For nested properties, only use the last part
    const dotLocation = string.lastIndexOf('.');
    if (dotLocation > 0 && dotLocation < string.length - 1) {
        string = string.substring(dotLocation + 1);
    }
    return camelCaseToHumanFriendly(string);
}
/**
 * Adds a single `parameter=value` query parameter to a URI. Mirrors
 * SharedUtil.addGetParameter.
 *
 * @param uri - the URI to which the parameter should be added.
 * @param parameter - the name of the parameter
 * @param value - the value of the parameter
 * @returns The modified URI with the parameter added
 */
export function addGetParameter(uri, parameter, value) {
    return addGetParameters(uri, `${parameter}=${value}`);
}
/**
 * Adds the given query parameters to a URI, before any fragment. Mirrors
 * SharedUtil.addGetParameters.
 *
 * @param uri - The uri to which the parameters should be added.
 * @param extraParams - One or more parameters in the format "a=b" or "c=d&e=f". An empty string is allowed but will not modify the url.
 * @returns The modified URI with the get parameters in extraParams added.
 */
export function addGetParameters(uri, extraParams) {
    if (extraParams === null || extraParams.length === 0) {
        return uri;
    }
    // RFC 3986: the query starts at the first "?" and ends at "#" or the URI end.
    let base = uri;
    let fragment = null;
    const hashPosition = base.indexOf('#');
    if (hashPosition !== -1) {
        // Fragment including "#"
        fragment = base.substring(hashPosition);
        // The full uri before the fragment
        base = base.substring(0, hashPosition);
    }
    base += base.includes('?') ? '&' : '?';
    base += extraParams;
    if (fragment !== null) {
        base += fragment;
    }
    return base;
}
/**
 * Converts a dash ("-") separated string into camelCase. Examples: `foo`
 * becomes `foo`, `foo-bar` becomes `fooBar`, `foo--bar` becomes `fooBar`.
 *
 * @param dashSeparated - The dash separated string to convert
 * @returns a camelCase version of the input string
 */
export function dashSeparatedToCamelCase(dashSeparated) {
    if (dashSeparated === null) {
        return null;
    }
    const parts = splitRemovingTrailingEmpty(dashSeparated, '-');
    for (let i = 1; i < parts.length; i++) {
        parts[i] = capitalize(parts[i]);
    }
    return join(parts, '');
}
/**
 * Converts a camelCase string into dash ("-") separated. Examples: `foo`
 * becomes `foo`, `fooBar` becomes `foo-bar`, `MyBeanContainer` becomes
 * `-my-bean-container`, `AwesomeURLFactory` becomes `-awesome-uRL-factory`,
 * `someUriAction` becomes `some-uri-action`.
 *
 * @param camelCaseString - The input string in camelCase format
 * @returns A dash separated version of the input
 */
export function camelCaseToDashSeparated(camelCaseString) {
    if (camelCaseString === null) {
        return null;
    }
    const parts = splitCamelCase(camelCaseString);
    if (parts[0].length >= 1 && isUpperCase(parts[0].charAt(0))) {
        // starts with upper case
        parts[0] = `-${firstToLower(parts[0])}`;
    }
    for (let i = 1; i < parts.length; i++) {
        parts[i] = firstToLower(parts[i]);
    }
    return join(parts, '-');
}
/**
 * Converts a UpperCamelCase string into dash ("-") separated lowercase.
 * Examples: `foo` becomes `foo`, `fooBar` becomes `foo-bar`,
 * `MyBeanContainer` becomes `my-bean-container`, `AwesomeURLFactory` becomes
 * `awesome-url-factory`, `someUriAction` becomes `some-uri-action`.
 *
 * @param upperCamelCaseString - The input string in UpperCamelCase format
 * @returns A dash separated lowercase version of the input
 */
export function upperCamelCaseToDashSeparatedLowerCase(upperCamelCaseString) {
    if (upperCamelCaseString === null) {
        return null;
    }
    return camelCaseToDashSeparated(firstToLower(upperCamelCaseString)).toLowerCase();
}
/**
 * Prepend the given url with the prefix if it is not absolute and doesn't have
 * a protocol.
 *
 * @param url - url to check
 * @param prefix - prefix to add to url
 * @returns prefixed url or url if absolute or has a protocol
 */
export function prefixIfRelative(url, prefix) {
    // Absolute
    if (url.startsWith('/')) {
        return url;
    }
    // Has a protocol
    // https://tools.ietf.org/html/rfc3986#section-3.1
    if (/^[a-zA-Z0-9.\-+]+:.*$/.test(url)) {
        return url;
    }
    return prefix + url;
}
//# sourceMappingURL=SharedUtil.js.map