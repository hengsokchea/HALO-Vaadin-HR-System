/*
 * Copyright 2000-2026 Vaadin Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/**
 * Returns whether the current browser exposes the Web Share API
 * (`navigator.share`). Used by the bootstrap path to seed the server-side
 * support signal without waiting for a DOM event.
 */
export function isShareSupported() {
    return typeof navigator.share === 'function';
}
//# sourceMappingURL=WebShare.js.map